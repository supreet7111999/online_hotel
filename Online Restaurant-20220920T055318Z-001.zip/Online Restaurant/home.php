<!doctype html>
<html lang="en">
  <head>
  <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <!-- Header section   -->
    <header class="header">
        <section class="flex">
          <a href="home.php" class="logo">HGC</a>
          <nav class="navbar" data-status='1'>
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="menu.php">Menu</a>
            <a href="orders.php">Orders</a>
            <a href="contact.php">Contact</a>
          </nav>
          <div class="icons">
            <a href="search.php"><i class="fas fa-search"></i></a>
            <a href="cart.php"><i class="fas fa-shopping-cart"></i><span>1</span></a>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="menu-btn" onclick="" class="fas fa-bars"></div>
          </div>
          <div class="profile">
            <p class="name">Supreet</p>
            <div class="flex">
                <a href="profile.php" class="btn">Profile</a>
                <a href="#" class="delete-btn">Log Out</a>
            </div>
            <p class="account">
                <a href="login.php">Login</a> or <a href="register.php">Register</a>
            </p>
          </div>
        </section>
    </header>  
   <!-- hero section -->
    
    <section class="hero">
      <div class="swiper hero-slider">
        <div class="swiper-wrapper">
          <div class="swiper-slide slide">
            <div class="content">
              <span>Order Online</span>
              <h3>Delicious Pizza</h3>
              <a href="menu.php" class="btn">See Menu</a>
            </div>
            <div class="image">
              <img src="images/home-img-1.png" alt="">
            </div>
          </div>
          <div class="swiper-slide slide">
            <div class="content">
              <span>Order Online</span>
              <h3>Chezzy HamBurger</h3>
              <a href="menu.php" class="btn">See Menu</a>
            </div>
            <div class="image">
              <img src="images/home-img-2.png" alt="">
            </div>
          </div>
          <div class="swiper-slide slide">
            <div class="content">
              <span>Order Online</span>
              <h3>Roasted Chicken</h3>
              <a href="menu.php" class="btn">See Menu</a>
            </div>
            <div class="image">
              <img src="images/home-img-3.png" alt="">
            </div>
          </div>

        </div>
        <div class="swiper-pagination"></div>
      </div>
    </section>
    <!-- category -->
    <section class="category">
      <h1 class="title">Food Category</h1>
      <div class="box-container">
        <a href="#" class="box">
          <img src="images/cat-1.png" alt="">
          <h3>Fast Food</h3>
        </a>
        <a href="#" class="box">
          <img src="images/cat-2.png" alt="">
          <h3>Main Dishes</h3>
        </a>
        <a href="#" class="box">
          <img src="images/cat-3.png" alt="">
          <h3>Drinks</h3>
        </a>
        <a href="#" class="box">
          <img src="images/cat-4.png" alt="">
          <h3>Desserts</h3>
        </a >
      </div>
    </section>
    
    <!-- home products -->
    
     <section class="products">
       <h1 class="title">
        Latest Dishes
       </h1>
       <div class="box-container">
          
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/burger-1.png" alt="">
            <a href="#" class="cat">Fast Food</a>
            <div class="name">Cheezy Burger</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/dish-1.png" alt="">
            <a href="#" class="cat">Dishes</a>
            <div class="name">Main Dishes</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/dessert-1.png" alt="">
            <a href="#" class="cat">Dessert</a>
            <div class="name">Delicious Dessert</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/drink-1.png" alt="">
            <a href="#" class="cat">Drinks</a>
            <div class="name">Cold Drink</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/pizza-1.png" alt="">
            <a href="#" class="cat">Fast Food</a>
            <div class="name">Delicious Pizza</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/dish-2.png" alt="">
            <a href="#" class="cat">Dishes</a>
            <div class="name">Main Dishes</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/dish-2.png" alt="">
            <a href="#" class="cat">Dishes</a>
            <div class="name">Main Dishes</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>
          <form method="post" action="" class="box">
            <button type="submit" class="fas fa-eye" name="quick_view"></button>
            <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
            <img src="uploaded_img/dish-2.png" alt="">
            <a href="#" class="cat">Dishes</a>
            <div class="name">Main Dishes</div>
            <div class="flex">
              <div class="price"><span>$</span>3</div>
              <input type="number" name="qty" class="qty" min="1" max="99" value="1"
              onkeypress="if(this.value.length==2) return false;" >
            </div>
          </form>

       </div>
       <div class="more-btn">
        <a href="menu.php">View More</a>
       </div>
     </section>

    <!-- footer -->
    <footer class="footer">
      <section class="grid">
        <div class="box">
          <img src="images/email-icon.png" alt="">
          <h3>Our Email</h3>
          <a href="mailto:supreet@gmail.com">supreet@gmail.com</a>
          <a href="mailto:supreet@gmail.com">supreet@gmail.com</a>
        </div>
        <div class="box">
          <img src="images/clock-icon.png" alt="">
          <h3>Opening Hours</h3>
          <p>00:07am to 00:10pm</p>
        </div>
        <div class="box">
          <img src="images/map-icon.png" alt="">
          <h3>Our Address</h3>
          <a href="#">Fatehpur,U.P.,India</a>
        </div>
        <div class="box">
          <img src="images/phone-icon.png" alt="">
          <h3>Our Number</h3>
          <a href="tel:123456789">123456789</a>
          <a href="tel:123456789">123456789</a>
        </div>
      </section>
      <div class="credit">Created by <span>Supreet Singh</span> | All rights reserved</div>
    </footer>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> -->
    <!-- <script type="text/javascript" src="../jquery/jquery.js"></script> -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- custom js -->
    <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
    <script>
      var swiper = new Swiper(".hero-slider", {
        loop:true,
        grabCursor: true,
        effect: "flip",
        pagination: {
          el: ".swiper-pagination",
          clickable:true,
        },
      });
    </script>
    <script src="js/script.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script> -->
    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> -->
  </body>
</html>